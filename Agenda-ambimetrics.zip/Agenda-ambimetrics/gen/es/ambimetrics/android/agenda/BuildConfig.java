/** Automatically generated file. DO NOT MODIFY */
package es.ambimetrics.android.agenda;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}